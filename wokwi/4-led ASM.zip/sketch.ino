#include "stm32c0xx.h"

void delay_ms(uint32_t ms);

int main(void) {
    // Enable clock for GPIOA
    RCC->IOPENR |= (1 << 0);

    // Configure PA2 as output
    GPIOA->MODER &= ~(3 << (2 * 2));  // Clear bits 5 and 4
    GPIOA->MODER |= (1 << (2 * 2));   // Set PA2 to output mode (01)

    while (1) {
        __asm__(
            "ldr r1, =0x50000000        \n"  // Load base address of GPIOA
            "ldr r0, [r1, #0x14]  \n"  // Load ODR (offset 0x14)
            "mov r2, #(1 << 2)    \n"  // Load (1 << 2) into r2
            "eor r0, r0, r2       \n"  // XOR bit 2 (toggle PA2)
            "str r0, [r1, #0x14]  \n"  // Store new ODR value back
        );

        delay_ms(500);
    }
}

void delay_ms(uint32_t ms) {
    for (volatile uint32_t i = 0; i < ms * 500; i++);
}
