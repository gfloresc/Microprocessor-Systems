#include "stm32c031xx.h"

/*
  Servo range used by Wokwi (and most SG90-type servos):
  0.54 ms -> 0 degrees, 2.40 ms -> 180 degrees
  (1.0..2.0 ms moves the Wokwi servo only about 90 degrees)
*/
#define SERVO_MIN   54U   /* CCR1 for a 0.54 ms pulse -> 0 degrees   */
#define SERVO_MAX  240U   /* CCR1 for a 2.40 ms pulse -> 180 degrees */

static void pwm_servo_init(void)
{
    /* Enable GPIOA clock */
    RCC->IOPENR |= RCC_IOPENR_GPIOAEN;

    /* PA6 -> Alternate Function */
    GPIOA->MODER &= ~(3U << (6U * 2U));
    GPIOA->MODER |=  (2U << (6U * 2U));

    /* PA6 -> AF1 = TIM3_CH1 */
    GPIOA->AFR[0] &= ~(0xFU << (6U * 4U)); // GPIOA Alternate Function Register LOW (AFRL)
    GPIOA->AFR[0] |=  (1U   << (6U * 4U));

    /* Enable TIM3 clock */
    RCC->APBENR1 |= RCC_APBENR1_TIM3EN;

    /*
      Timer clock:
      48 MHz / 480 = 100 kHz  -> 1 tick = 10 us
      ARR = 2000 -> 20 ms period -> 50 Hz
    */
    TIM3->PSC = 480U - 1U;
    TIM3->ARR = 2000U - 1U;

    /* PWM mode 1 on CH1 */
    TIM3->CCMR1 &= ~(7U << 4);
    TIM3->CCMR1 |=  (6U << 4);

    /* Preload */
    TIM3->CCMR1 |= TIM_CCMR1_OC1PE;
    TIM3->CR1   |= TIM_CR1_ARPE;

    /* Enable CH1 output */
    TIM3->CCER |= TIM_CCER_CC1E;

    /* Start centered */
    TIM3->CCR1 = 150U;

    /* Update registers */
    TIM3->EGR |= TIM_EGR_UG;

    /* Start timer */
    TIM3->CR1 |= TIM_CR1_CEN;
}

int main(void)
{
    uint32_t angle = 0U;   /* <-- choose the servo position: 0 to 180 degrees */
    uint32_t ccr_value;

    pwm_servo_init();

    while (1)
    {
        /* Keep the angle inside the servo range */
        if (angle > 180U) {
            angle = 180U;
        }

        /*
          Map angle 0..180 degrees to CCR1 54..240
          (pulse 0.54..2.40 ms)
        */
        ccr_value = SERVO_MIN + (angle * (SERVO_MAX - SERVO_MIN)) / 180U;
                    // 0 deg   -> CCR1 = 54  -> pulse 0.54 ms
                    // 90 deg  -> CCR1 = 147 -> pulse 1.47 ms
                    // 180 deg -> CCR1 = 240 -> pulse 2.40 ms

        TIM3->CCR1 = ccr_value;
    }
}