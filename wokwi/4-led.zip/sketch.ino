#include "stm32c0xx.h"

void delay_ms(uint32_t ms);

int main(void) {
    // 1. Enable the clock for GPIOA
    RCC->IOPENR |= (1 << 0);  // Activate the clock for port A (GPIOA)

    // 2. Configure PA2 as an output
    GPIOA->MODER &= ~(3 << (2 * 2));  // Clear PA2 configuration
    GPIOA->MODER |= (1 << (2 * 2));   // Set PA2 as output (01)

    while (1) {
        GPIOA->ODR ^= (1 << 2);  // Toggle PA2 (LED ON/OFF)
        delay_ms(500);           // Wait for 500 ms
    }
}

// Simple delay function based on cycles
void delay_ms(uint32_t ms) {
    for (volatile uint32_t i = 0; i < ms * 500; i++);
}
