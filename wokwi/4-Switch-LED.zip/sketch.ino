#include "stm32c0xx.h"

#define LED_PIN 2   // PA2 for LED
#define BTN_PIN 0   // PA0 for Button

void delay_ms(uint32_t ms);

int main(void) {
    // 1. Enable clock for GPIOA
    RCC->IOPENR |= (1 << 0);

    // 2. Configure PA2 as Output (LED)
    GPIOA->MODER &= ~(3 << (LED_PIN * 2));  // Clear mode bits
    GPIOA->MODER |= (1 << (LED_PIN * 2));   // Set PA2 as output (01)

    // 3. Configure PA0 as Input (Button)
    GPIOA->MODER &= ~(3 << (BTN_PIN * 2));  // Set PA0 as input (00)
    GPIOA->PUPDR |= (1 << (BTN_PIN * 2));   // Enable pull-up resistor (01)

    while (1) {
        // Read button state
        if (GPIOA->IDR & (1 << BTN_PIN)) {
            GPIOA->ODR |= (1 << LED_PIN);  // Turn on LED
        } else {
            GPIOA->ODR &= ~(1 << LED_PIN); // Turn off LED
        }
    }
}

void delay_ms(uint32_t ms) {
    for (volatile uint32_t i = 0; i < ms * 500; i++);
}
