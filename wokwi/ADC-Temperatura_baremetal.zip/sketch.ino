#include "stm32c031xx.h"
#include <stdint.h>

const uint8_t segment_map[10] = {
    0b00111111,  // 0
    0b00000110,  // 1
    0b01011011,  // 2
    0b01001111,  // 3
    0b01100110,  // 4
    0b01101101,  // 5
    0b01111101,  // 6
    0b00000111,  // 7
    0b01111111,  // 8
    0b01101111   // 9
};

/* ===== ADC bits used ===== */
#define ADC_CR_ADEN_BIT        (1U << 0)
#define ADC_CR_ADSTART_BIT     (1U << 2)
#define ADC_CR_ADVREGEN_BIT    (1U << 28)
#define ADC_CR_ADCAL_BIT       (1U << 31)

#define ADC_ISR_ADRDY_BIT      (1U << 0)
#define ADC_ISR_EOC_BIT        (1U << 2)

/* --------------------------------------------------------- */
/* Simple delay                                               */
/* --------------------------------------------------------- */
static void small_delay(volatile uint32_t count)
{
    while (count--) {
        __asm__("nop");
    }
}

/* --------------------------------------------------------- */
/* GPIO init                                                  */
/* PB0..PB6 -> outputs for 7-segment                         */
/* PA0     -> analog input for ADC_IN0                       */
/* --------------------------------------------------------- */
static void gpio_init(void)
{
    /* Enable GPIOA and GPIOB clocks */
    RCC->IOPENR |= RCC_IOPENR_GPIOAEN | RCC_IOPENR_GPIOBEN;

    /* ---- PA0 as analog mode ----
       MODER[1:0] = 11 */
    GPIOA->MODER &= ~(3U << (0 * 2));
    GPIOA->MODER |=  (3U << (0 * 2));

    /* Optional: no pull-up / no pull-down */
    GPIOA->PUPDR &= ~(3U << (0 * 2));

    /* ---- PB0..PB6 as general purpose outputs ---- */
    for (int i = 0; i <= 6; i++) {
        GPIOB->MODER &= ~(3U << (i * 2));
        GPIOB->MODER |=  (1U << (i * 2));   /* 01 = output */
    }

    /* Push-pull, low speed, no pull */
    GPIOB->OTYPER &= ~0x7F;
    GPIOB->OSPEEDR &= ~(0x3FFFU);
    GPIOB->PUPDR &= ~(0x3FFFU);

    /* Clear PB0..PB6 */
    GPIOB->ODR &= ~0x7F;
}

/* --------------------------------------------------------- */
/* ADC init                                                   */
/* ADC1 channel 0 (PA0)                                      */
/* --------------------------------------------------------- */
static void adc_init(void)
{
    /* Enable ADC clock */
    RCC->APBENR2 |= RCC_APBENR2_ADCEN;

    /* Enable ADC internal voltage regulator */
    ADC1->CR |= ADC_CR_ADVREGEN_BIT;

    /* Wait a little for regulator stabilization */
    small_delay(2000);

    /* Start calibration */
    ADC1->CR |= ADC_CR_ADCAL_BIT;

    /* Wait until calibration completes */
    while (ADC1->CR & ADC_CR_ADCAL_BIT) {
    }

    /* Select channel 0 */
    ADC1->CHSELR = (1U << 0);

    /* Clear ADRDY flag by writing 1, just in case */
    ADC1->ISR |= ADC_ISR_ADRDY_BIT;

    /* Enable ADC */
    ADC1->CR |= ADC_CR_ADEN_BIT;

    /* Wait until ADC is ready */
    while (!(ADC1->ISR & ADC_ISR_ADRDY_BIT)) {
    }
}

/* --------------------------------------------------------- */
/* Single ADC read                                            */
/* --------------------------------------------------------- */
static uint16_t adc_read(void)
{
    /* Start conversion */
    ADC1->CR |= ADC_CR_ADSTART_BIT;

    /* Wait until conversion is complete */
    while (!(ADC1->ISR & ADC_ISR_EOC_BIT)) {
    }

    /* Return 12-bit result */
    return (uint16_t)ADC1->DR;
}

/* --------------------------------------------------------- */
/* Display number 0..9 on PB0..PB6                           */
/* --------------------------------------------------------- */
static void display_number(uint8_t number)
{
    if (number > 9) number = 9;

    uint8_t pattern = segment_map[number];

    /* Clear PB0..PB6 */
    GPIOB->ODR &= ~0x7F;

    /* Write new pattern */
    GPIOB->ODR |= pattern;
}

int main(void)
{
    gpio_init();
    adc_init();

    while (1) {
        uint16_t adc_value = adc_read();

        /* Scale 0..4095 to 0..9 --> 10 possible values */
        uint8_t display_num = (adc_value * 10U) / 4095U;
        //uint8_t display_num = (adc_value * 10U) >> 12;  
        // Map ADC range 0–4095 to display range 0–9 using a right shift (division by 4096)

        display_number(display_num);

        small_delay(120000);
    }
}